GetGraphAdjList <- function(G) {
  al.list <- as.list(rep(NA, length(G)))
  for (i in 1:length(G)) {
    al.list[[i]] <- as_adj_list(G[[i]])
  }
  al.list
}

GetGraphAdjMat <- function(G) {
  am.list <- as.list(rep(NA, length(G)))
  for (i in 1:length(G)) {
    am.list[[i]] <- as_adj(G[[i]])
    ## am.list[[i]] <- as_adj(G[[i]], sparse = FALSE)
  }
  am.list
}
