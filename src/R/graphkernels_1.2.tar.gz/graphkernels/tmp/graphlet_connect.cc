#include <RcppEigen.h>
#define Int int32_t

// [[Rcpp::plugins(cpp11)]]
// [[Rcpp::depends(RcppEigen)]]

using Eigen::Map;
using Eigen::SparseMatrix;
using Eigen::LLT;

typedef Eigen::Triplet<double> T;

using namespace Rcpp;
using namespace Eigen;
using namespace std;

template <typename S>
ostream &operator<<(ostream& out, const vector<S>& vec) {
  for (Int i = 0; i < vec.size() - 1; ++i) { cout << vec[i] << " "; }
  cout << vec[vec.size() - 1];
  return out;
}

void getMinValue(SparseMatrix<Int>& am, vector<Int>& idx, vector<Int>& sums) {
  sums.clear();
  sums.resize(idx.size());
  fill(sums.begin(), sums.end(), 0);
  for (Int i = 0; i < (Int)idx.size(); ++i) {
    Int k = idx[i];
    for (SparseMatrix<Int>::InnerIterator it(am, k); it; ++it) {
      if(find(idx.begin(), idx.end(), it.row()) != idx.end()) {
	sums[i] += it.value();
      }
    }
  }
  sums.push_back(1);
}
template<typename V>
void countConnectedGraphletsFive(SparseMatrix<Int>& am, vector<vector<Int>>& al, V&& count) {
  vector<double> w = {1.0/120.0, 1.0/72.0, 1.0/48.0, 1.0/36.0, 1.0/28.0, 1.0/20.0, 1.0/14.0, 1.0/10.0, 1.0/12.0, 1.0/8.0, 1.0/8.0, 1.0/4.0, 1.0/2.0, 1.0/12.0, 1.0/12.0, 1.0/4.0, 1.0/4.0, 1.0/2.0, 0.0, 0.0, 0.0};
  Int n = (Int)am.rows();
  vector<Int> L1(n);
  iota(L1.begin(), L1.end(), 0);
  vector<Int> idx(5);
  vector<Int> sums;

  for (auto&& i : L1) {
    for (auto&& j : al[i]) {
      for (auto&& k : al[j]) {
	if (k != i) {
	  for (auto&& l : al[k]) {
	    if (l != i && l != j) {
	      for (auto&& m : al[l]) {
		if (m != i && m != j && m != k) {
		  Int aux = am.coeff(i, k) + am.coeff(i, l) + am.coeff(i, m) + am.coeff(j, l) + am.coeff(j, m) + am.coeff(k, m);
		  if (aux == 6) {
		    count[0] += w[0];
		  } else if (aux == 5) {
		    count[1] += w[1];
		  } else if (aux == 4) {
		    idx[0] = i; idx[1] = j; idx[2] = k; idx[3] = l; idx[4] = m;
		    getMinValue(am, idx, sums);
		    Int aux1 = *min_element(sums.begin(), sums.end());
		    if (aux1 == 2) {
		      count[3] += w[3];
		    } else {
		      count[2] += w[2];
		    }
		  } else if (aux == 3) {
		    idx[0] = i; idx[1] = j; idx[2] = k; idx[3] = l; idx[4] = m;
		    getMinValue(am, idx, sums);
		    sort(sums.begin(), sums.end());
		    if (sums[0] == 1) {
		      count[8] += w[8];
		    } else if (sums[1] == 3) {
		      count[4] += w[4];
		    } else if (sums[2]== 2) {
		      count[13] += w[13];
		    } else {
		      count[5] += w[5];
		    }
		  } else if (aux == 2) {
		    idx[0] = i; idx[1] = j; idx[2] = k; idx[3] = l; idx[4] = m;
		    getMinValue(am, idx, sums);
		    vector<Int> aux1;
		    copy(sums.begin(), sums.end(), back_inserter(aux1));
		    sort(aux1.begin(), aux1.end());
		    if (aux1[0] == 1) {
		      if (aux1[2] == 2) {
			count[15] += w[15];
		      } else {
			count[9] += w[9];
		      }
		    } else {
		      if (aux1[3] == 2) {
			count[10] += w[10];
		      } else {
			vector<Int> ind;
			for (Int ii = 0; ii < (Int)sums.size(); ++ii) {
			  if (sums[ii] == 3) ind.push_back(ii);
			}
			// idx[0] = i; idx[1] = j; idx[2] = k; idx[3] = l; idx[4] = m;
			if (am.coeff(idx[ind[0]], idx[ind[1]]) == 1) {
			  count[6] += w[6];
			} else {
			  count[14] += w[14];
			}
		      }
		    }
		  } else if (aux == 1) {
		    idx[0] = i; idx[1] = j; idx[2] = k; idx[3] = l; idx[4] = m;
		    getMinValue(am, idx, sums);
		    vector<Int> aux1;
		    copy(sums.begin(), sums.end(), back_inserter(aux1));
		    sort(aux1.begin(), aux1.end());
		    if (aux1[0] == 2) {
		      count[7] += w[7];
		    } else if (aux1[1] == 1) {
		      count[17] += w[17];
		    } else {
		      vector<Int> ind;
		      for (Int ii = 0; ii < (Int)sums.size(); ++ii) {
			if (sums[ii] == 3) ind.push_back(ii);
		      }
		      for (Int ii = 0; ii < (Int)sums.size(); ++ii) {
			if (sums[ii] == 1) ind.push_back(ii);
		      }
		      if (am.coeff(idx[ind[0]], idx[ind[1]]) == 1) {
			count[16] += w[16];
		      } else {
			count[11] += w[11];
		      }
		    }
		  } else {
		    count[12] += w[12];
		  }
		}
	      }
	    }
	  }
	}
      }
    }
    // count graphlets of type 20
    for (auto&& j : al[i]) {
      for (auto&& k : al[j]) {
	if (k != i && am.coeff(i, k) == 0) {
	  for (auto&& l : al[k]) {
	    if (l != i && l != j && am.coeff(i, l) == 0 && am.coeff(j, l) == 0) {
	      for (auto&& m : al[k]) {
		if (m != i && m != j && m != l && am.coeff(i, m) == 0 && am.coeff(j, m) == 0 && am.coeff(l, m) == 0) {
		  count[19] += w[19];
		}
	      }
	    }
	  }
	}
      }
    }
    // count graphlets of type 19 and 21
    for (Int j = 0; j < (Int)al[i].size() - 3; ++j) {
      for (Int k = j + 1; k < (Int)al[i].size() - 2; ++k) {
	for (Int l = k + 1; l < (Int)al[i].size() - 1; ++l) {
	  for (Int m = l + 1; m < (Int)al[i].size(); ++m) {
	    Int aux = am.coeff(al[i][j], al[i][k]) + am.coeff(al[i][j], al[i][l])
	      + am.coeff(al[i][j], al[i][m]) + am.coeff(al[i][k], al[i][l])
	      + am.coeff(al[i][k], al[i][m]) + am.coeff(al[i][l], al[i][m]);
	    if (aux == 1) {
	      count[18]++;
	    } else if (aux == 0) {
	      count[20]++;
	    }
	  }
	}
      }
    }
  }
}
template<typename V>
void countConnectedGraphletsFour(SparseMatrix<Int>& am, vector<vector<Int>>& al, V&& count) {
  vector<double> w = {1.0/24.0, 1.0/12.0, 1.0/4.0, 0.0, 1.0/8.0, 1.0/2.0};
  Int n = (Int)am.rows();
  vector<Int> L1(n);
  iota(L1.begin(), L1.end(), 0);

  for (auto&& i : L1) {
    for (auto&& j : al[i]) {
      for (auto&& k : al[j]) {
	if (k != i) {
	  for (auto&& l : al[k]) {
	    if (l != i && l != j){
	      Int aux = am.coeff(i, k) + am.coeff(i, l) + am.coeff(j, l);
	      if (aux == 3) {
		count[0] += w[0];
	      } else if (aux == 2) {
		count[1] += w[1];
	      } else if (aux == 1) {
		if (am.coeff(i, l) == 1) {
		  count[4] += w[4];
		} else {
		  count[2] += w[2];
		}
	      } else {
		count[5] += w[5];
	      }
	    }
	  }
	}
      }
    }

    // count "stars"
    for (Int j = 0; j < (Int)al[i].size() - 2; ++j) {
      for (Int k = j + 1; k < (Int)al[i].size() - 1; ++k) {
	for (Int l = k + 1; l < (Int)al[i].size(); ++l) {
	  if (am.coeff(al[i][j], al[i][k]) == 0 && am.coeff(al[i][j], al[i][l]) == 0 && am.coeff(al[i][k], al[i][l]) == 0) {
	    count[3]++;
	  }
	}
      }
    }
  }
}
template<typename V>
void countConnectedGraphletsThree(SparseMatrix<Int>& am, vector<vector<Int>>& al, V&& count) {
  vector<double> w = {1.0/2.0, 1.0/6.0};
  Int n = (Int)am.rows();
  vector<Int> L1(n);
  iota(L1.begin(), L1.end(), 0);

  for (auto&& i : L1) {
    for (auto&& j : al[i]) {
      for (auto&& k : al[j]) {
	if (k != i) {
	  if (am.coeff(i, k) == 1) {
	    count[1] += w[1];
	  } else {
	    count[0] += w[0];
	  }
	}
      }
    }
  }
}

// [[Rcpp::export]]
void graphlet_connected(vector<SparseMatrix<Int>>& graph_adj_all, vector<vector<vector<Int>>>& graph_adjlist_all, Int k) {
  // decrement one to start indices from zero
  for (auto&& X : graph_adjlist_all)
    for (auto&& vec : X)
      for (auto&& x : vec) x--;

  MatrixXd freq;
  Int freq_size;
  switch (k) {
  case 3: freq_size = 2; break;
  case 4: freq_size = 6; break;
  case 5: freq_size = 21; break;
  }
  freq = MatrixXd::Zero(graph_adj_all.size(), freq_size);

  vector<Int> idx_graph(graph_adj_all.size());
  iota(idx_graph.begin(), idx_graph.end(), 0);
  for (auto&& i : idx_graph) {
    if (k == 3)
      countConnectedGraphletsThree(graph_adj_all[i], graph_adjlist_all[i], freq.row(i));
    else if (k == 4)
      countConnectedGraphletsFour(graph_adj_all[i], graph_adjlist_all[i], freq.row(i));
    else if (k == 5)
      countConnectedGraphletsFive(graph_adj_all[i], graph_adjlist_all[i], freq.row(i));
    if (freq.row(i).sum() != 0) {
      freq.row(i) /= freq.row(i).sum();
    }
  }
  MatrixXd K = freq * freq.transpose();
  cout << "K:" << endl << K << endl;

  /*
  for (auto&& am : graph_adj_all) {
    cout << "am:" << endl << am << endl;
  }

  for (auto&& al : graph_adjlist_all) {
    cout << "al:" << endl;
    for (auto&& vec : al) {
      cout << vec << endl;
    }
  }
  */

}
